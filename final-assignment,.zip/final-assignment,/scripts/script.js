// Hangman Game Script - Final Enhanced Version with Local Images
let words = [];
let selectedWord = '';
let selectedHint = '';
let guessedLetters = [];
let mistakes = 0;
const maxMistakes = 6;
const hangmanImages = [
    'images/hangman1.jpg',
    'images/hangman2.jpg',
    'images/hangman3.jpg',
    'images/hangman4.jpg',
    'images/hangman5.jpg',
    'images/hangman6.jpg',
    'images/hangman7.jpg'
];

async function loadWords() {
    try {
        const response = await fetch('scripts/words.json');
        const data = await response.json();
        words = data.words;
        startGame();
    } catch (error) {
        console.error('Error loading words:', error);
        showMessage('Error loading words. Please check your connection.', 'error');
    }
}

function startGame() {
    const randomIndex = Math.floor(Math.random() * words.length);
    selectedWord = words[randomIndex].word.toUpperCase();
    selectedHint = words[randomIndex].hint;
    guessedLetters = [];
    mistakes = 0;
    updateWordDisplay();
    updateHangmanImage();
    showMessage(`Guess the word: ${selectedWord.length} letters. Hint: ${selectedHint}`, 'info');
    generateLetterButtons();
    document.getElementById('play-again').style.display = 'none';
}

function showMessage(text, type) {
    const messageElement = document.getElementById('message');
    messageElement.innerText = text;
    messageElement.style.color = (type === 'win') ? 'green' : (type === 'lose') ? 'red' : '#333';
}

function generateLetterButtons() {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const letterButtons = alphabet.split('').map(letter => `
        <button class="letter-btn" onclick="handleGuess('${letter}')" id="btn-${letter}">${letter}</button>
    `).join('');
    document.getElementById('letter-buttons').innerHTML = letterButtons;
}

function handleGuess(letter) {
    const button = document.getElementById(`btn-${letter}`);
    if (!guessedLetters.includes(letter)) {
        guessedLetters.push(letter);
        if (selectedWord.includes(letter)) {
            updateWordDisplay();
            checkWin();
            button.style.backgroundColor = '#4caf50'; // Green for correct
        } else {
            mistakes++;
            updateHangmanImage();
            checkLose();
            button.style.backgroundColor = '#e74c3c'; // Red for incorrect
        }
        button.disabled = true;
        button.style.color = '#777';
    } else {
        showMessage('Letter already guessed!', 'warning');
    }
}

function updateHangmanImage() {
    const image = document.getElementById('hangman-image');
    image.src = hangmanImages[mistakes];
}

function updateWordDisplay() {
    const display = selectedWord.split('').map(letter => (guessedLetters.includes(letter) ? letter : '_')).join(' ');
    document.getElementById('word-container').innerText = display;
}

function checkWin() {
    if (selectedWord.split('').every(letter => guessedLetters.includes(letter))) {
        showMessage('You Win! 🎉', 'win');
        disableAllButtons();
        document.getElementById('play-again').style.display = 'block';
    }
}

function checkLose() {
    if (mistakes === maxMistakes) {
        showMessage(`Game Over! The word was: ${selectedWord}`, 'lose');
        disableAllButtons();
        document.getElementById('play-again').style.display = 'block';
    }
}

function disableAllButtons() {
    const buttons = document.querySelectorAll('.letter-btn');
    buttons.forEach(button => button.disabled = true);
}

function resetGame() {
    startGame();
}

loadWords();
